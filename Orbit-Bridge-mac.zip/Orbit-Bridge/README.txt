Orbit bridge for Mac
====================
1. Open Terminal, cd into this folder, run:   ./install.sh
2. A browser page with two QR codes opens.
   - Orbit -> Claude tab -> "扫码连接"  : scan the "Claude" code
   - Orbit -> 音乐 tab -> "扫码添加"    : scan the "音乐" code
3. First time Orbit controls Music, macOS asks to allow it: click OK.
Uninstall: ./install.sh --uninstall
